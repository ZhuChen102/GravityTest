//
//  ViewController.m
//  GravityTest
//
//  Created by Zhu on 2017/11/27.
//  Copyright © 2017年 ZhuChen. All rights reserved.
//

#import "ViewController.h"
#import <CoreMotion/CoreMotion.h>
@interface ViewController () <UIScrollViewDelegate>
{
    NSTimeInterval updateInterval;
    CGFloat _setx;//scroll的动态偏移量
    CGFloat _sety;//scroll的动态偏移量
}
@property (nonatomic, strong) CMMotionManager *mManager;
@property (nonatomic, strong) UIScrollView *myScrollView;
@property (nonatomic, assign) CGFloat offsetX;//初始偏移量

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _setx = 0;
    _sety = 0;
    [self createView];
    [self startUpdateAccelerometerResult:0];
}
- (void)createView{
    _myScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    _myScrollView.delegate = self;
    _myScrollView.contentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width+480, [UIScreen mainScreen].bounds.size.height+480);
    _myScrollView.contentOffset = CGPointMake(240, 240);
    _myScrollView.userInteractionEnabled = NO;
    [self.view addSubview:_myScrollView];
    
    UIImageView *testImageV = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width+480, [UIScreen mainScreen].bounds.size.height+480)];
    testImageV.image = [UIImage imageNamed:@"Image"];
    [_myScrollView addSubview:testImageV];
}
#pragma mark - 重力感应
- (CMMotionManager *)mManager
{
    if (!_mManager) {
        updateInterval = 1.0/100.0;
        _mManager = [[CMMotionManager alloc] init];
    }
    return _mManager;
}
//开始
- (void)startUpdateAccelerometerResult:(void (^)(NSInteger))result{
     if ([self.mManager isAccelerometerAvailable] == YES) {
        //回调会一直调用,建议获取到就调用下面的停止方法，需要再重新开始，当然如果需求是实时不间断的话可以等离开页面之后再stop
        [self.mManager setAccelerometerUpdateInterval:updateInterval];
        [self.mManager startAccelerometerUpdatesToQueue:[NSOperationQueue currentQueue] withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
            
            if(error) {
                [self.mManager stopAccelerometerUpdates];
            }else{
                double x = accelerometerData.acceleration.x;
                double y = accelerometerData.acceleration.y;
                double z = accelerometerData.acceleration.z;
//                double angleX =
//                double zTheta =atan2(z,sqrtf(x*x+y*y))/M_PI*(-90.0)*2-90;
//                double xyTheta =atan2(x,y)/M_PI*1480.0;
                    if (x>0) { //右旋转 x最大为1
                            _setx = 480*x;
                            if (_setx>=240) {
                                _setx= 240;
                            }
//                        }
                    }else if (x<0) { //左旋转
                            _setx = 480*x;
                            if (_setx<=-240) {
                                _setx= -240;
                            }
                    }else {
                        _setx = 0;
                    }
                y=y+0.5;
                if (y>0) { //前
                    _sety = 480*y;
                    if (_sety>=240) {
                        _sety= 240;
                    }
                }else if (y<0) { //后
                    _sety = 480*y;
                    if (_sety<=-240) {
                        _sety= -240;
                    }
                }else {
                    _sety = 0;
                }
                
                    [UIView animateWithDuration:0.3f
                                          delay:0.0f
                                        options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionCurveEaseOut
                                     animations:^{
                                         [_myScrollView setContentOffset:CGPointMake(240+_setx, 240+_sety)];
                                     }completion:nil];
                NSLog(@"%0.2f====%0.2f====%0.2f",x,y,z);
            }
         }];
    }
}

//停止感应方法
- (void)stopUpdate {
    if ([self.mManager isAccelerometerActive] == YES) {
        [self.mManager stopAccelerometerUpdates];
    }
}
@end
